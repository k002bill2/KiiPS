---
name: kiips-log-analyzer
description: Analyzes KiiPS service logs for errors, performance issues, and patterns. Use for troubleshooting and monitoring.
---

# KiiPS Log Analyzer Skill

## Purpose
Automated analysis of KiiPS microservice logs for debugging and monitoring.

## Log Location
```bash
# Service logs
KiiPS-ServiceName/logs/log.YYYY-MM-DD-0.log

# Example
KiiPS-FD/logs/log.2025-12-28-0.log
KiiPS-IL/logs/log.2025-12-28-0.log
```

## Analysis Commands

### Find Errors
```bash
# Today's errors
grep -i "error\|exception" logs/log.$(date "+%Y-%m-%d")-0.log

# With context (5 lines before/after)
grep -i -C 5 "error\|exception" logs/log.$(date "+%Y-%m-%d")-0.log

# Count errors by type
grep -i "error\|exception" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '{print $5}' | sort | uniq -c | sort -rn

# Errors in last hour
grep -i "error\|exception" logs/log.$(date "+%Y-%m-%d")-0.log \
  | tail -1000

# Find specific error
grep -i "NullPointerException" logs/log.$(date "+%Y-%m-%d")-0.log
```

### Performance Analysis
```bash
# Find slow queries (>1000ms)
grep "execution time" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '$NF > 1000'

# API response times
grep "API" logs/log.$(date "+%Y-%m-%d")-0.log \
  | grep -oP "time=\K[0-9]+" \
  | awk '{sum+=$1; count++} END {print "Avg:", sum/count, "ms"}'

# Slowest queries
grep "execution time" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '{print $NF, $0}' | sort -rn | head -10

# Database connection pool status
grep -i "connection pool" logs/log.$(date "+%Y-%m-%d")-0.log
```

### Traffic Patterns
```bash
# Requests per endpoint
grep "GET\|POST\|PUT\|DELETE" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '{print $7}' | sort | uniq -c | sort -rn

# Requests per hour
grep "GET\|POST\|PUT\|DELETE" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '{print $2}' | cut -d: -f1 | sort | uniq -c

# HTTP status codes distribution
grep "HTTP" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '{print $9}' | sort | uniq -c | sort -rn

# Most active users
grep "username" logs/log.$(date "+%Y-%m-%d")-0.log \
  | awk '{print $10}' | sort | uniq -c | sort -rn | head -20
```

### Error Investigation
```bash
# Find stack traces
grep -A 10 "Exception" logs/log.$(date "+%Y-%m-%d")-0.log

# Find specific user's errors
grep "userId=123" logs/log.$(date "+%Y-%m-%d")-0.log \
  | grep -i "error"

# Time-based error search (between 14:00-15:00)
sed -n '/14:00/,/15:00/p' logs/log.$(date "+%Y-%m-%d")-0.log \
  | grep -i "error"

# Find failed transactions
grep -i "transaction.*failed" logs/log.$(date "+%Y-%m-%d")-0.log
```

## Automated Monitoring Script

### Basic Monitor
```bash
#!/bin/bash
# kiips-log-monitor.sh

LOG_FILE="logs/log.$(date "+%Y-%m-%d")-0.log"

echo "=== Error Summary ==="
echo "Total Errors: $(grep -c "ERROR" $LOG_FILE)"
echo "Total Exceptions: $(grep -c "Exception" $LOG_FILE)"
echo ""

echo "=== Last 10 Errors ==="
grep "ERROR" $LOG_FILE | tail -10
echo ""

echo "=== Performance Alerts (>2000ms) ==="
grep "execution time" $LOG_FILE | awk '$NF > 2000'
echo ""

echo "=== Memory Warnings ==="
grep -i "memory\|heap" $LOG_FILE | tail -5
```

### Advanced Monitor with Alerts
```bash
#!/bin/bash
# kiips-advanced-monitor.sh

LOG_FILE="logs/log.$(date "+%Y-%m-%d")-0.log"
ERROR_THRESHOLD=100
SLOW_QUERY_THRESHOLD=2000

# Count errors
ERROR_COUNT=$(grep -c "ERROR" $LOG_FILE)

if [ $ERROR_COUNT -gt $ERROR_THRESHOLD ]; then
  echo "⚠️  ALERT: High error rate detected ($ERROR_COUNT errors)"
  echo "Last 5 errors:"
  grep "ERROR" $LOG_FILE | tail -5
fi

# Check slow queries
SLOW_QUERIES=$(grep "execution time" $LOG_FILE | awk "\$NF > $SLOW_QUERY_THRESHOLD" | wc -l)

if [ $SLOW_QUERIES -gt 0 ]; then
  echo "⚠️  ALERT: $SLOW_QUERIES slow queries detected (>$SLOW_QUERY_THRESHOLD ms)"
  grep "execution time" $LOG_FILE | awk "\$NF > $SLOW_QUERY_THRESHOLD" | head -5
fi

# Check connection pool
grep -i "connection.*exhausted" $LOG_FILE
if [ $? -eq 0 ]; then
  echo "🚨 CRITICAL: Database connection pool exhausted!"
fi
```

## Multi-Service Analysis

### Check All Services
```bash
#!/bin/bash
# check-all-services.sh

SERVICES=("KiiPS-FD" "KiiPS-IL" "KiiPS-PG" "KiiPS-COMMON")
TODAY=$(date "+%Y-%m-%d")

for service in "${SERVICES[@]}"; do
  echo "=== $service ==="
  LOG_FILE="$service/logs/log.$TODAY-0.log"

  if [ -f "$LOG_FILE" ]; then
    echo "Errors: $(grep -c ERROR $LOG_FILE)"
    echo "Warnings: $(grep -c WARN $LOG_FILE)"
    echo "Last error:"
    grep ERROR $LOG_FILE | tail -1
  else
    echo "Log file not found: $LOG_FILE"
  fi
  echo ""
done
```

## Alert Triggers

### Critical Alerts (Immediate Action)
- ERROR count > 100/hour
- Response time > 5000ms
- Database connection pool exhausted
- Memory usage > 90%
- Disk usage > 85%
- Service crash/restart

### Warning Alerts (Monitor)
- ERROR count > 50/hour
- Response time > 2000ms
- Memory usage > 80%
- Disk usage > 75%
- Slow queries > 1000ms

### Info Alerts (Track)
- WARNING count > 100/hour
- API Gateway timeout
- Cache hit rate < 70%

## Real-Time Monitoring

### Watch Logs Live
```bash
# Follow logs with color highlighting
tail -f logs/log.$(date "+%Y-%m-%d")-0.log | \
  grep --color=always -E 'ERROR|WARN|Exception|$'

# Multiple services
tail -f KiiPS-*/logs/log.$(date "+%Y-%m-%d")-0.log

# Filter specific patterns
tail -f logs/log.$(date "+%Y-%m-%d")-0.log | \
  grep --line-buffered -i "error\|exception\|failed"
```

## When to Use This Skill
- Troubleshooting production issues
- Performance degradation investigation
- Error pattern analysis
- Capacity planning (traffic analysis)
- Security audit (access patterns)
- Post-deployment verification
- Regular health checks
