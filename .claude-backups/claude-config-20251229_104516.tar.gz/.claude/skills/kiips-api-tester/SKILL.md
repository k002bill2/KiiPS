---
name: kiips-api-tester
description: Tests KiiPS API Gateway endpoints and service integration. Use for API testing, JWT validation, and routing verification.
---

# KiiPS API Gateway Tester Skill

## Purpose
Automated testing of KiiPS API Gateway and microservice endpoints.

## Authentication

### Get JWT Token
```bash
# Login and get token
curl -X POST http://localhost:8801/api/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "password"}' \
  | jq -r '.token'

# Save token to variable
TOKEN=$(curl -s -X POST http://localhost:8801/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password"}' \
  | jq -r '.token')

echo "Token: $TOKEN"
```

### Test with JWT
```bash
# Call through API Gateway
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/funds/list

# With pretty-print
curl -s -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/funds/list | jq '.'
```

## Service Endpoints Testing

### Fund Management (FD - Port 8601)
```bash
# List funds
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/funds/list

# Get fund details
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/funds/123

# Create fund (POST)
curl -X POST \
     -H "X-AUTH-TOKEN: $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"name": "테스트펀드", "amount": 1000000000}' \
     http://localhost:8000/api/funds/create
```

### Investment Management (IL - Port 8401)
```bash
# List investments
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/investments/list

# Create investment
curl -X POST \
     -H "X-AUTH-TOKEN: $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"amount": 1000000, "fundId": 123}' \
     http://localhost:8000/api/investments/create

# Get investment details
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/investments/456
```

### Program Management (PG - Port 8201)
```bash
# List programs
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/programs/list

# Get program details
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/programs/789
```

## Service-to-Service Testing

### Direct Service Call (Skip Gateway)
```bash
# Call service directly (for internal testing)
curl -H "x-api-key: internal-service-key" \
     http://localhost:8601/api/internal/funds/stats

# Verify service is running
curl http://localhost:8601/actuator/health
```

### Gateway Routing Verification
```bash
# Test routing through gateway
curl -H "X-AUTH-TOKEN: $TOKEN" \
     -w "\nStatus: %{http_code}\nTime: %{time_total}s\n" \
     http://localhost:8000/api/funds/list
```

## Load Testing

### Simple Load Test with Apache Bench
```bash
# Install ab (if needed)
# brew install apache-bench

# 1000 requests, 10 concurrent
ab -n 1000 -c 10 \
   -H "X-AUTH-TOKEN: $TOKEN" \
   http://localhost:8000/api/funds/list

# With output file
ab -n 1000 -c 10 \
   -H "X-AUTH-TOKEN: $TOKEN" \
   -g load-test-results.tsv \
   http://localhost:8000/api/funds/list
```

### Performance Metrics
```bash
# Measure response time
time curl -s -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/funds/list > /dev/null

# Multiple endpoints
for endpoint in funds investments programs; do
  echo "Testing $endpoint..."
  time curl -s -H "X-AUTH-TOKEN: $TOKEN" \
       http://localhost:8000/api/$endpoint/list > /dev/null
done
```

## Error Testing

### Test Error Handling
```bash
# Invalid token
curl -H "X-AUTH-TOKEN: invalid-token" \
     http://localhost:8000/api/funds/list

# Missing token
curl http://localhost:8000/api/funds/list

# Non-existent endpoint
curl -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/nonexistent/endpoint

# Invalid method
curl -X DELETE \
     -H "X-AUTH-TOKEN: $TOKEN" \
     http://localhost:8000/api/funds/list
```

## Test Checklist

### Pre-Test Verification
- [ ] All services are running (check health endpoints)
- [ ] API Gateway is accessible (port 8000)
- [ ] JWT authentication service is running (port 8801)
- [ ] Test data is prepared

### Test Execution
- [ ] Authentication works (can get JWT token)
- [ ] JWT authentication working (valid token accepted)
- [ ] Invalid authentication rejected (401/403)
- [ ] API Gateway routing correct (requests reach services)
- [ ] Service responds within SLA (<200ms p95)
- [ ] Error handling proper (4xx, 5xx responses)
- [ ] Response format correct (JSON structure)
- [ ] CORS headers present (if needed)
- [ ] Pagination working (if applicable)
- [ ] Filtering/sorting working (if applicable)

### Post-Test Verification
- [ ] No errors in service logs
- [ ] Performance metrics acceptable
- [ ] Memory usage stable
- [ ] No resource leaks

## When to Use This Skill
- After deploying new services
- Testing API Gateway configuration changes
- Verifying authentication flow
- Performance testing
- Integration testing
- Troubleshooting API issues
