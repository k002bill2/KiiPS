/**
 * Stop Event Hook
 * 
 * Claude의 응답이 완료된 후 실행되어
 * 코드 변경사항을 분석하고 자가 검증 체크리스트를 표시합니다.
 */

const fs = require('fs');
const path = require('path');

/**
 * Hook entry point
 * @param {object} context - Hook 실행 컨텍스트
 */
async function onStopEvent(context) {
  try {
    // 편집된 파일 목록 가져오기
    const editedFiles = context.editedFiles || [];
    
    if (editedFiles.length === 0) {
      return; // 변경사항 없으면 종료
    }
    
    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📋 CODE CHANGES SELF-CHECK');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    console.log(`⚠️  Changes detected in ${editedFiles.length} file(s)\n`);
    
    // 파일별 리스크 패턴 분석
    const reminders = new Set();
    
    for (const filePath of editedFiles) {
      await analyzeFile(filePath, reminders);
    }
    
    // 체크리스트 표시
    if (reminders.size > 0) {
      console.log('Self-check questions:');
      Array.from(reminders).forEach(reminder => {
        console.log(`❓ ${reminder}`);
      });
      console.log('\n💡 Remember: All errors should be properly handled and logged to Sentry');
    } else {
      console.log('✅ No critical patterns detected');
    }
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
  } catch (error) {
    console.error('[StopEvent] Error:', error.message);
  }
}

/**
 * 파일 분석 및 리스크 패턴 검사
 * @param {string} filePath - 분석할 파일 경로
 * @param {Set} reminders - 리마인더 메시지 Set
 */
async function analyzeFile(filePath, reminders) {
  try {
    if (!fs.existsSync(filePath)) {
      return;
    }
    
    const content = fs.readFileSync(filePath, 'utf-8');
    const fileName = path.basename(filePath);
    const ext = path.extname(filePath);
    
    // Java 파일 패턴 검사
    if (ext === '.java') {
      checkJavaPatterns(content, fileName, reminders);
    }
    
    // JavaScript/JSP 파일 패턴 검사
    if (ext === '.js' || ext === '.jsp') {
      checkJavaScriptPatterns(content, fileName, reminders);
    }
    
    // MyBatis XML 패턴 검사
    if (ext === '.xml' && content.includes('<!DOCTYPE mapper')) {
      checkMyBatisPatterns(content, fileName, reminders);
    }
    
  } catch (error) {
    console.error(`[StopEvent] Error analyzing ${filePath}:`, error.message);
  }
}

/**
 * Java 파일 패턴 검사
 */
function checkJavaPatterns(content, fileName, reminders) {
  // 에러 처리 패턴
  if (/try\s*{/.test(content)) {
    reminders.add('Did you add proper error handling in try-catch blocks?');
  }
  
  // 비동기 작업
  if (/@Async|CompletableFuture|Future/.test(content)) {
    reminders.add('Are async operations properly handled with error callbacks?');
  }
  
  // 트랜잭션
  if (/@Transactional/.test(content)) {
    reminders.add('Is transaction rollback properly configured for exceptions?');
  }
  
  // 예외 던지기
  if (/throw\s+new/.test(content)) {
    reminders.add('Are custom exceptions logged to Sentry (Sentry.captureException)?');
  }
  
  // REST Controller
  if (/@RestController|@Controller/.test(content)) {
    reminders.add('Did you add @Valid for request body validation?');
    reminders.add('Is GlobalExceptionHandler configured for this endpoint?');
  }
  
  // Service 레이어
  if (/@Service/.test(content)) {
    reminders.add('Are all business exceptions properly wrapped and logged?');
  }
}

/**
 * JavaScript/JSP 패턴 검사
 */
function checkJavaScriptPatterns(content, fileName, reminders) {
  // 비동기 작업
  if (/async\s+function|\.then\(|\.catch\(/.test(content)) {
    reminders.add('Are async/promise operations properly handled with error callbacks?');
  }
  
  // AJAX 호출
  if (/\$\.ajax|\$\.get|\$\.post|fetch\(/.test(content)) {
    reminders.add('Did you add error handling for AJAX/fetch requests?');
  }
  
  // try-catch
  if (/try\s*{/.test(content)) {
    reminders.add('Are errors in try-catch properly logged or displayed to user?');
  }
}

/**
 * MyBatis XML 패턴 검사
 */
function checkMyBatisPatterns(content, fileName, reminders) {
  // SQL Injection 위험 패턴
  if (/\$\{[^}]+\}/.test(content)) {
    reminders.add('⚠️  WARNING: ${} syntax detected - ensure no SQL injection vulnerability!');
    reminders.add('Consider using #{} parameter binding instead of ${}');
  }
  
  // DELETE/UPDATE 쿼리
  if (/<delete|<update/.test(content)) {
    reminders.add('Did you add WHERE clause for DELETE/UPDATE queries?');
  }
  
  // Dynamic SQL
  if (/<if|<foreach|<choose/.test(content)) {
    reminders.add('Test all branches of dynamic SQL conditions');
  }
}

// Export for Claude Code Hook system
module.exports = { onStopEvent };
