/**
 * UserPromptSubmit Hook
 * 
 * Claude가 사용자 프롬프트를 보기 전에 실행되어
 * skill-rules.json의 규칙을 기반으로 관련 Skills를 강제 활성화합니다.
 */

const fs = require('fs');
const path = require('path');

/**
 * Hook entry point
 * @param {string} prompt - 사용자의 원본 프롬프트
 * @param {object} context - Hook 실행 컨텍스트
 * @returns {string} - 수정된 프롬프트 (Skills 활성화 메시지 포함)
 */
async function onUserPromptSubmit(prompt, context) {
  try {
    // skill-rules.json 로드
    const projectRoot = context.workspaceRoot || process.cwd();
    const rulesPath = path.join(projectRoot, 'skill-rules.json');
    
    if (!fs.existsSync(rulesPath)) {
      console.log('[UserPromptSubmit] skill-rules.json not found, skipping skill activation');
      return prompt;
    }

    const rulesContent = fs.readFileSync(rulesPath, 'utf-8');
    const rules = JSON.parse(rulesContent);
    
    // 활성화할 스킬 목록
    const activatedSkills = [];
    
    // 각 스킬 규칙 검사
    for (const [skillName, rule] of Object.entries(rules)) {
      if (shouldActivateSkill(prompt, rule)) {
        activatedSkills.push({
          name: skillName,
          priority: rule.priority,
          enforcement: rule.enforcement
        });
      }
    }
    
    // 우선순위별 정렬 (critical > high > normal > low)
    const priorityOrder = { 'critical': 0, 'high': 1, 'normal': 2, 'low': 3 };
    activatedSkills.sort((a, b) => 
      priorityOrder[a.priority] - priorityOrder[b.priority]
    );
    
    // Skills 활성화 메시지 생성
    if (activatedSkills.length > 0) {
      const skillMessage = generateActivationMessage(activatedSkills);
      return skillMessage + '\n\n' + prompt;
    }
    
    return prompt;
    
  } catch (error) {
    console.error('[UserPromptSubmit] Error:', error.message);
    // 에러가 발생해도 원본 프롬프트는 반환하여 작업 중단 방지
    return prompt;
  }
}

/**
 * 스킬 활성화 여부 판단
 * @param {string} prompt - 사용자 프롬프트
 * @param {object} rule - 스킬 규칙
 * @returns {boolean}
 */
function shouldActivateSkill(prompt, rule) {
  const lowerPrompt = prompt.toLowerCase();
  
  // 키워드 체크
  if (rule.promptTriggers && rule.promptTriggers.keywords) {
    const hasKeyword = rule.promptTriggers.keywords.some(keyword =>
      lowerPrompt.includes(keyword.toLowerCase())
    );
    if (hasKeyword) return true;
  }
  
  // 의도 패턴 체크 (정규식)
  if (rule.promptTriggers && rule.promptTriggers.intentPatterns) {
    const hasIntent = rule.promptTriggers.intentPatterns.some(pattern => {
      try {
        const regex = new RegExp(pattern, 'i');
        return regex.test(prompt);
      } catch (e) {
        console.error(`[UserPromptSubmit] Invalid regex pattern: ${pattern}`);
        return false;
      }
    });
    if (hasIntent) return true;
  }
  
  return false;
}

/**
 * 스킬 활성화 메시지 생성
 * @param {Array} skills - 활성화된 스킬 목록
 * @returns {string}
 */
function generateActivationMessage(skills) {
  const criticalSkills = skills.filter(s => s.priority === 'critical');
  const highSkills = skills.filter(s => s.priority === 'high');
  const otherSkills = skills.filter(s => s.priority !== 'critical' && s.priority !== 'high');
  
  let message = '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
  message += '🎯 SKILL ACTIVATION CHECK\n';
  message += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n';
  
  if (criticalSkills.length > 0) {
    message += '🔴 **CRITICAL** - Must follow:\n';
    criticalSkills.forEach(skill => {
      const icon = skill.enforcement === 'block' ? '🚫' : '⚠️';
      message += `${icon} ${skill.name}\n`;
    });
    message += '\n';
  }
  
  if (highSkills.length > 0) {
    message += '🟡 **HIGH PRIORITY** - Strongly recommended:\n';
    highSkills.forEach(skill => {
      message += `✓ ${skill.name}\n`;
    });
    message += '\n';
  }
  
  if (otherSkills.length > 0) {
    message += '🟢 **SUGGESTED**:\n';
    otherSkills.forEach(skill => {
      message += `• ${skill.name}\n`;
    });
    message += '\n';
  }
  
  message += '**IMPORTANT**: Load and follow the guidelines from these skills.\n';
  message += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
  
  return message;
}

// Export for Claude Code Hook system
module.exports = { onUserPromptSubmit };
