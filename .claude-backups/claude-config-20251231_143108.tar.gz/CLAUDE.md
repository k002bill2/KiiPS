# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## Agentic Workflow Protocol (v5.4)

### Primary Directive
모든 작업 요청에 대해:
1. 순차적 사고(sequential thinking)를 통한 요청 분석
2. 실행 가능한 체크리스트 생성 (3-7개의 개념적 단계)
3. 체계적 실행 및 각 항목 완료 후 상태 업데이트
4. 검증 수행 후 자기 교정 (validation 실패 시)

### Checklist Protocol

**생성 규칙:**
- 항목은 순차적으로 번호 부여 (①, ②, ③... 또는 1, 2, 3...)
- 각 항목은 원자적(atomic)이고 검증 가능해야 함
- 현실적인 완료 예상 및 비상 계획 포함

**진행 상태 표시:**
```
[✓] ① 분석 완료 → 3개 요구사항 식별
[✓] ② 컨텍스트 분석 완료
[⚡] ③ 작업 진행 중... (40%)
[ ] ④ 검증 대기 중
[✗] ⑤ 실패 → 대체 방법 수행
```

### Core Thinking Principles
- 증거에 기반한 판단
- 문서보다 코드를 먼저 확인
- 장황함보다 효율성 우선
- 복잡한 작업은 실행 가능한 단계로 분해
- 각 단계는 명확한 완료 기준 보유
- 진행 상황 투명하게 추적 및 표시

### Quality Assurance Checklist
모든 출력은 다음을 통과해야 함:
1. ✓ 구문(Syntax) 검증
2. ✓ 타입 안전성
3. ✓ 코드 품질
4. ✓ 보안 검사
5. ✓ 테스트 커버리지 (단위 ≥80%, 통합 ≥70%)
6. ✓ 성능 벤치마크
7. ✓ 문서 완성도
8. ✓ 통합 검증

### Dynamic Persona System

**Technical Roles:**
- `architect`: 시스템 설계
- `frontend`: UI/UX
- `backend`: API/서버
- `security`: 취약점 검사
- `performance`: 최적화

**Process Roles:**
- `analyzer`: 조사/분석
- `qa`: 테스팅
- `refactorer`: 코드 개선
- `devops`: 배포

---

## 📚 Documentation Index

KiiPS 프로젝트의 상세 정보는 다음 문서를 참조하세요:

| 문서 | 내용 | 용도 |
|------|------|------|
| **[architecture.md](./architecture.md)** | 시스템 아키텍처, 모듈 구조, 통신 패턴 | 설계 및 구조 이해 |
| **[api.md](./api.md)** | API Gateway, 엔드포인트, 인증, 에러 처리 | API 개발 및 연동 |
| **[deployment.md](./deployment.md)** | 빌드, 배포, 환경 관리, 서비스 관리 | 배포 및 운영 |
| **[troubleshooting.md](./troubleshooting.md)** | 문제 해결, 디버깅, 긴급 대응 | 장애 대응 및 문제 해결 |

---

## Project Quick Reference

### Overview

**KiiPS** (Korea Investment Information Processing System)
- 마이크로서비스 기반 엔터프라이즈 플랫폼
- Spring Boot 2.4.2, Java 8
- 20+ 독립 서비스
- Maven Multi-Module 구조

### Key Technologies

- **Backend**: Spring Boot 2.4.2, Java 8
- **Gateway**: Spring Cloud Gateway
- **Database**: (DAO via KiiPS-UTILS)
- **Frontend**: JSP, jQuery, Bootstrap, RealGrid 2.8.8 (주력), ApexCharts (주력), AnyChart (보조)
- **Version Control**: SVN
- **Build Tool**: Maven

---

## 🚀 Quick Start Commands

### Building the Project

<!-- **⚠️ CRITICAL**: Always build from KiiPS-HUB parent directory -->
**CRITICAL** Before performing ANY file operations (read, write, edit, delete, create) in a subdirectory, you MUST FIRST automatically read any "CLAUDE.md" file present in that target directory. This is a mandatory first step, not optional. If a "CLAUDE.md"exists in the subdirectory, read it immediately before processing the requested file operation to understand the context-specific instructions and information.

```bash
# Build entire project
cd KiiPS-HUB/
mvn clean package

# Build specific module with dependencies
cd KiiPS-HUB/
mvn clean package -pl :KiiPS-UI -am
mvn clean package -pl :KiiPS-FD -am

# Skip tests (default)
mvn clean package -DskipTests=true
```

### Running Services

```bash
# Navigate to service directory
cd KiiPS-FD/  # or any other service

# Start service
./start.sh

# Stop service
./stop.sh

# View logs
tail -f logs/log.$(date "+%Y-%m-%d")-0.log
```

### Development

```bash
# Hot reload with Spring Boot DevTools
./mvnw spring-boot:run

# Remote debugging (port 5005)
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005 -jar service.jar
```

---

## 🏗️ Architecture at a Glance

### Core Modules

| 모듈 | 역할 | 상세 정보 |
|------|------|-----------|
| **KiiPS-HUB** | Parent POM | [architecture.md](./architecture.md#multi-module-maven-structure) |
| **KIIPS-APIGateway** | Gateway & Routing | [api.md](./api.md#api-gateway-configuration) |
| **KiiPS-COMMON** | Shared Services | [architecture.md](./architecture.md#kiips-common-structure) |
| **KiiPS-UTILS** | Shared DAOs | [architecture.md](./architecture.md#kiips-utils-structure) |
| **KiiPS-UI** | Web Interface (WAR) | [architecture.md](./architecture.md#ui-module-kiips-ui) |
| **KiiPS-Login** | Authentication & JWT | [api.md](./api.md#authentication) |

### Business Modules

펀드(FD), 투자(IL), 프로그램(PG), 회계(AC), 시스템(SY), LP, 전자문서(EL), 리포팅(RT), 배치(BATCH), 모바일(MOBILE), KSD, AI 등

👉 전체 모듈 목록: [architecture.md - Business Domain Modules](./architecture.md#business-domain-modules)

### Service Communication

```
Client → API Gateway (8000) → Service (8xxx)
                ↓
          Authentication (KiiPS-Login)
                ↓
          Shared Services (KiiPS-COMMON)
                ↓
          Data Access (KiiPS-UTILS)
```

👉 상세 흐름: [api.md - Authentication Flow](./api.md#authentication-flow)

---

## 🔧 Development Essentials

### Environment Configuration

각 서비스는 환경별 프로퍼티 파일 지원:

- `app-local.properties` - 로컬 개발
- `app-stg.properties` - 스테이징
- `app-kiips.properties` - 프로덕션

👉 상세 설정: [architecture.md - Environment Configuration](./architecture.md#environment-configuration)

### Service Ports (Local)

| Service | Port | Service | Port |
|---------|------|---------|------|
| Gateway | 8000 | Login | 8801 |
| Common | 8701 | UI | 8100 |
| FD | 8601 | IL | 8401 |
| PG | 8201 | (Others) | 8xxx |

👉 전체 포트 목록: [api.md - Service Endpoints](./api.md#service-endpoints)

### Custom Headers

- `X-AUTH-TOKEN`: JWT 인증 토큰
- `logostoken`: 커스텀 인증 토큰
- `LIB`: 라이브러리 버전
- `x-api-key`: Service-to-Service 호출

👉 헤더 상세: [api.md - Custom Headers](./api.md#custom-headers)

---

# Nested Directory Context
This subdirectory ("/nested/") contains test files and examples for demonstrating hierarchical project organization.

## ⚡ Common Tasks

### 1. Build a Service

```bash
# 1. Navigate to KiiPS-HUB
cd KiiPS-HUB/

# 2. Build with dependencies
mvn clean package -pl :KiiPS-ServiceName -am

# 3. Artifact location
ls -la ../KiiPS-ServiceName/target/*.{jar,war}
```

### 2. Add New REST Endpoint

1. Controller: `src/main/java/com/kiips/{domain}/controll/`
2. Service: `src/main/java/com/kiips/{domain}/service/`
3. DAO: Use KiiPS-UTILS or add to `dao/`
4. Test: API Gateway routing rules

👉 참조: [architecture.md - Project Structure](./architecture.md#standard-service-structure)

### 3. Handle Exceptions

- **Global**: KiiPS-COMMON의 `GlobalExceptionHandler` 자동 처리
- **Slack 알림**: `ErrorNotificationService` 자동 전송
- **커스텀**: Service layer에서 비즈니스 예외 throw

👉 참조: [api.md - Error Handling](./api.md#error-handling)

### 4. Call Another Service

```java
@Autowired
private Common_API_Service commonApiService;

// Service-to-Service call
String url = "http://localhost:8401/api/investments/...";
Map<String, String> headers = Map.of("x-api-key", "key");
Result result = commonApiService.get(url, Result.class, headers);
```

👉 참조: [api.md - Service-to-Service Communication](./api.md#service-to-service-communication)

---

## 🔍 Troubleshooting Quick Index

문제 발생 시 **[troubleshooting.md](./troubleshooting.md)**를 먼저 확인하세요!

| 문제 유형 | 빠른 참조 |
|-----------|-----------|
| 🔨 **빌드 문제** | [Build Issues](./troubleshooting.md#-build-issues) |
| ⚡ **런타임 문제** | [Runtime Issues](./troubleshooting.md#-runtime-issues) |
| 🚀 **배포 문제** | [Deployment Issues](./troubleshooting.md#-deployment-issues) |
| 💾 **DB 문제** | [Database Issues](./troubleshooting.md#-database-issues) |
| 🌐 **API 문제** | [API Issues](./troubleshooting.md#-api-issues) |
| 🐢 **성능 문제** | [Performance Issues](./troubleshooting.md#-performance-issues) |

---

## 📝 Important Notes

### Build Rules

1. **항상 KiiPS-HUB에서 빌드** - 의존성 해결 보장
2. **빌드 순서** - COMMON → UTILS → 서비스
3. **`-am` 플래그 사용** - 의존성 자동 빌드

### Version Control

- **SVN 사용** (Git 아님)
- 빌드 스크립트에 `svn up` 포함

### Testing

- 기본적으로 비활성화 (`<skipTests>true</skipTests>`)
- 활성화 시 `pom.xml` 수정 필요

### UI Module (KiiPS-UI)

- **패키징**: WAR (다른 서비스는 JAR)
- **뷰**: JSP
- **보안**: Lucy XSS 필터
- **리소스**: `src/main/resources/static/`

---

## 🎯 Development Workflow

### 빠른 워크플로우

```bash
# 1. SVN 업데이트
cd KiiPS-ServiceName/ && svn up

# 2. 빌드
cd ../KiiPS-HUB/
mvn clean package -pl :KiiPS-ServiceName -am

# 3. 실행
cd ../KiiPS-ServiceName/
./start.sh && tail -f logs/log.$(date "+%Y-%m-%d")-0.log
```

👉 상세 배포 프로세스: [deployment.md - Development Workflow](./deployment.md#-development-workflow)

---

## 🏁 Summary

이 프로젝트에서 작업 시:

1. **문서 먼저 확인**: 필요한 정보를 해당 문서에서 찾기
2. **KiiPS-HUB에서 빌드**: 의존성 해결 필수
3. **공통 기능 활용**: KiiPS-COMMON, KiiPS-UTILS
4. **환경별 설정**: `app-*.properties`
5. **문제 발생 시**: `troubleshooting.md` 우선 확인

## 🤖 Claude Code Skills

KiiPS 프로젝트에는 다음 전문 Skills가 구성되어 있습니다:

### Available Skills
- **kiips-maven-builder** - Maven Multi-Module 빌드 자동화
- **kiips-service-deployer** - 마이크로서비스 배포 관리
- **kiips-api-tester** - API Gateway 테스트 및 검증
- **kiips-log-analyzer** - 로그 분석 및 모니터링
- **kiips-feature-planner** - Feature 개발 계획 수립 및 진행 관리
- **checklist-generator** - 코드 리뷰, 배포, 테스트 체크리스트 자동 생성

### Skill Activation

Skills는 `skill-rules.json`에 정의된 규칙에 따라 **자동으로 활성화**됩니다:
- 키워드 매칭 (예: "빌드", "배포", "로그")
- 파일 패턴 매칭 (예: `pom.xml`, `start.sh`)
- Intent 패턴 매칭 (정규식 기반)

#### 자동 활성화 시스템

**문제**: Claude가 Skills를 만들어놔도 실제로 사용하지 않는 문제
**해결**: Hook 시스템으로 강제 활성화!

**작동 방식**:
1. **UserPromptSubmit Hook** - 사용자 입력 전에 관련 Skills 자동 감지 및 활성화
2. **Stop Event Hook** - 작업 완료 후 코드 변경사항 자가 검증
3. **skill-rules.json** - 모든 Skill 트리거 규칙 중앙 관리

**우선순위 레벨**:
- `critical` - 필수 준수 (예: DB 변경, 보안)
- `high` - 강력 권장 (예: 빌드, 배포)
- `normal` - 일반 제안 (예: 코드 리뷰)
- `low` - 선택 사항 (예: 유튜브 수집)

**Enforcement 레벨**:
- `block` - 작업 차단 (예: DB 스키마 변경)
- `require` - 필수 적용 (예: Maven 빌드 규칙)
- `suggest` - 권장 사항 (예: API 테스트)

### Configuration Files
- `.claudecode.json` - Hooks, 권한, 환경 설정
- `skill-rules.json` - Skills 자동 활성화 규칙 ⭐
- `.claude/hooks/userPromptSubmit.js` - Skill 자동 활성화 Hook
- `.claude/hooks/stopEvent.js` - 코드 변경 자가 검증 Hook
- `dev/` - Dev Docs 3-파일 시스템 (plan, context, tasks)

---

## 📚 Complete Documentation Map

```
CLAUDE.md (이 파일)
│
├─ architecture.md     → 시스템 구조, 모듈, 통신 패턴
├─ api.md             → API Gateway, 인증, 엔드포인트
├─ deployment.md      → 빌드, 배포, 환경 관리
├─ troubleshooting.md → 문제 해결, 디버깅, 긴급 대응
│
├─ .claudecode.json   → Claude Code 설정 (Hooks, 권한)
├─ skill-rules.json   → Skills 자동 활성화 규칙
│
└─ .claude/
    ├─ skills/        → KiiPS 전문 Skills (5개)
    └─ ...            → 기타 설정
```

**Quick Links:**
- 🏗️ [Architecture](./architecture.md) - 시스템 설계
- 🌐 [API Spec](./api.md) - API 개발
- 🚀 [Deployment](./deployment.md) - 배포 운영
- 🔧 [Troubleshooting](./troubleshooting.md) - 문제 해결
- 📖 [Skills Guide](./skills%20guide/) - Claude Code 활용 가이드

---

**Last Updated**: 2025-12-28
**Claude Code Version**: v2.0.76
**Skills**: kiips-maven-builder, kiips-service-deployer, kiips-api-tester, kiips-log-analyzer, kiips-feature-planner
